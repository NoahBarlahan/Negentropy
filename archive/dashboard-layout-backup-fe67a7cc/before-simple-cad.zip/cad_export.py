"""Explicit-unit SOLIDWORKS global-variable files from frozen model snapshots."""
from copy import deepcopy
from datetime import datetime, timezone
import csv
import hashlib
import io
import zipfile
from config import dumps, effective, validate
from model import build

EQUATIONS_FILE='negentropy_equations.txt'
HELP_URL='https://help.solidworks.com/2023/english/SolidWorks/sldworks/t_EQN_Importing_Equations.htm'


def parameters(data):
    c=effective(data)
    rows=[]
    def add(name,value,unit,meaning,expression=None):
        rows.append(dict(variable=name,value=float(value),unit=unit,meaning=meaning,
                         equation=expression or f'{float(value):.8f}'.rstrip('0').rstrip('.')+' '+unit))
    for name,key,meaning in (
        ('HipSpacing','spacing','Distance between left and right hip pitch axes'),
        ('PlatformLength','platform_l','Platform envelope along local x'),
        ('PlatformWidth','platform_w','Platform envelope along local y'),
        ('PlatformThickness','platform_t','Platform thickness along local z'),
        ('PlatformOffsetX','platform_x','Platform center x relative to pelvis'),
        ('PlatformOffsetZ','platform_z','Platform center z relative to pelvis'),
        ('ServoLength','servo_l','Servo envelope x; not a mounting-hole specification'),
        ('ServoWidth','servo_w','Servo envelope y; not a mounting-hole specification'),
        ('ServoHeight','servo_h','Servo envelope z; not a mounting-hole specification'),
        ('MountingGap','pack_gap','Assumed envelope clearance; not a print fit allowance'),
        ('PoseHipHeight','pelvis_z','Hip midpoint world z in the exported pose'),
    ): add(name,c[key],'mm',meaning)
    add('PosePelvisPitch',c['pitch'],'deg','Model pelvis pitch; map CAD mate signs to your axes')
    add('ReferenceOverallHeight',build(c)['height']*1000,'mm','Measured modeled envelope height; reference only, not a link length')
    for side in ('L','R'):
        for name,key,meaning in (
            ('ThighLength','thigh','Hip pitch axis to knee pitch axis; center-to-center'),
            ('ShinLength','shin','Knee pitch axis to link endpoint before foot attachment offset'),
            ('FootOffsetX','foot_ox','Foot reference offset in shin-local x'),
            ('FootOffsetZ','foot_oz','Foot reference offset in shin-local z'),
        ): add(name+'_'+side,c[f'{side}_{key}'],'mm',meaning)
        for joint in ('hip','knee'):
            add('Pose'+joint.title()+'Angle_'+side,c[f'{side}_{joint}'],'deg',
                'Model joint angle; reference pose, not calibrated servo travel')
            for axis in 'xyz':
                add(joint.title()+'CaseOffset'+axis.upper()+'_'+side,
                    c[f'{side}_{joint}_case_{axis}'],'mm','Visual case center relative to joint in its carrier frame')
        if c['foot_model']=='Rounded nub':
            add('FootRadius_'+side,c[f'{side}_nub_radius'],'mm','Spherical nub radius; sphere center is endpoint plus foot offsets')
            add('FootDiameter_'+side,2*c[f'{side}_nub_radius'],'mm','Derived spherical nub diameter',
                f'2 * "FootRadius_{side}"')
        else:
            for name,key in (('FootLength','foot_l'),('FootWidth','foot_w'),('FootThickness','foot_t')):
                add(name+'_'+side,c[f'{side}_{key}'],'mm','Flat sole envelope')
            add('FootAttachmentAngle_'+side,c[f'{side}_foot_angle'],'deg','Rigid sole angle relative to shin')
    return rows


def equations(data):
    # CRLF, plain ASCII, decimal points and explicit units; no prose in importer file.
    return ''.join(f'"{r["variable"]}" = {r["equation"]}\r\n' for r in parameters(data))


def finalize(data):
    config=deepcopy(validate(data))
    signature=hashlib.sha256(dumps(config).encode('utf-8')).hexdigest()[:12]
    return {'config':config,'revision':signature,
            'created':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'parameters':parameters(config),'text':equations(config)}


def instructions(snapshot):
    c=effective(snapshot['config'])
    return f'''NEGENTROPY - SOLIDWORKS PARAMETER HANDOFF
Revision: {snapshot['revision']}
Finalized: {snapshot['created']}
Foot contact model: {c['foot_model']}
Symmetry enabled: {c['symmetry']} (right parameters use effective mirrored values)

START YOUR CAD
1. Extract this package into a permanent folder beside your SolidWorks project.
2. Open {EQUATIONS_FILE} in Notepad to inspect or edit the named parameters.
   Keep the straight double quotes, decimal points, and explicit mm/deg units.
3. In a SolidWorks part or assembly choose Tools > Equations > Import.
   Select {EQUATIONS_FILE}. Select Link to File if your edition supports it
   and you want later edits to that file to update the CAD. Import the variables.
4. Create your sketches, features and mates. Set their driving dimensions to
   the imported variables, for example enter ="ThighLength_L" for the distance
   between hip and knee axis centers, and ="ShinLength_L" for the distance from
   knee axis to the shin endpoint. Choose the variables from the equation list.
5. For rounded feet, place the sphere center at the shin endpoint plus
   FootOffsetX_L / FootOffsetZ_L in shin-local coordinates. Drive the sphere's
   diameter with ="FootDiameter_L". Use corresponding _R names for the right.
6. Import/link the same text file in each part that needs these variables;
   assembly global variables are not automatically shared with every part.
7. Rebuild and check dimensions/units, mirrored geometry and mate-angle signs.

UPDATING DIMENSIONS
Finalize a new snapshot in the dashboard and replace the SAME linked
{EQUATIONS_FILE} at its existing path, then rebuild your CAD. Keep revision
packages separately for history. If you imported without linking, re-import
the revised values. Check the equations dialog for successful updates.
Do not rename established variables after using them in dimensions.
Editing this file does not send changes back to the dashboard. Load the included
biped_config.json in the dashboard to restore this export's source design.

DIMENSION MEANINGS AND SCOPE
See parameter_map.csv for each variable's value, unit and physical definition.
Thigh/shin values are joint-reference lengths, not outside printed-part lengths.
For a rounded nub with zero offset, ShinLength ends at the sphere center.
Pose* variables describe one model pose. ReferenceOverallHeight is a measured
envelope result, not an independent sketch constraint to apply alongside lengths.
Payload is a lumped mass without a physical envelope; height excludes its size.
The exporter uses explicit mm and deg regardless of dashboard display units.
Negative offsets and joint angles are intentional model coordinates.

This file supplies global variables. It does not generate parts, identify your
sketch dimension names, create mates, or size brackets and holes. Measure servo
mounting holes, output-shaft position, horn/spline, fasteners, bearing seats,
wall thickness and print fits before designing those features. ServoLength,
ServoWidth and ServoHeight are envelope assumptions, not a dimensioned drawing.
Finalized means a frozen design snapshot, not verified engineering performance.
Dynamic balance, structural strength and continuous servo torque remain unverified.

Official import/link instructions: {HELP_URL}
'''


def bundle(snapshot):
    buffer=io.BytesIO()
    mapping=io.StringIO(newline='')
    fields=['variable','value','unit','meaning','equation']
    writer=csv.DictWriter(mapping,fieldnames=fields);writer.writeheader();writer.writerows(snapshot['parameters'])
    with zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr(EQUATIONS_FILE,snapshot['text'])
        archive.writestr('START_HERE.txt',instructions(snapshot))
        archive.writestr('parameter_map.csv',mapping.getvalue())
        archive.writestr('biped_config.json',dumps(snapshot['config']))
    return buffer.getvalue()
